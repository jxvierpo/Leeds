const app = require("./app");

// iniciar servidor
app.listen(3000, () => {
  console.log("server on port 3000");
  console.log("y ke paza");
});
